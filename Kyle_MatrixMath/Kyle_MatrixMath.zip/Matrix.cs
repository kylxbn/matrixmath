﻿// Matrix library
// Kyle Alexander Buan
// A part of MatrixMath
// November 23, 2015

namespace Kyle_MatrixMath
{
    class Matrix
    {
        double[,] Cells;
        public bool error;
        public string errorMessage;

        public int MatrixWidth { get; }

        public int MatrixHeight { get; }

        public Matrix(int width, int height, bool identity = false)
        {
            error = false;
            errorMessage = "";

            MatrixWidth = width;
            MatrixHeight = height;
            Cells = new double[MatrixWidth, MatrixHeight];

            for (int y = 0; y < MatrixHeight; y++)
                for (int x = 0; x < MatrixWidth; x++)
                {
                    Cells[x, y] = (identity && x == y) ? 1 : 0;
                }
        }

        public double GetCell(int x, int y)
        {
            return Cells[x, y];
        }

        public void SetCell(int x, int y, double val)
        {
            Cells[x, y] = val;
        }

        public void CopyTo(ref Matrix M)
        {
            M = new Matrix(MatrixWidth, MatrixHeight);
            for (int y = 0; y < MatrixHeight; y++)
                for (int x = 0; x < MatrixWidth; x++)
                    M.SetCell(x, y, Cells[x, y]);
        }

        public Matrix Add(Matrix M)
        {
            Matrix Res = new Matrix(MatrixWidth, MatrixHeight);

            if (MatrixWidth == M.MatrixWidth && MatrixHeight == M.MatrixHeight)
            {
                for (int y = 0; y < MatrixHeight; y++)
                    for (int x = 0; x < MatrixWidth; x++)
                        Res.SetCell(x, y, Cells[x, y] + M.GetCell(x, y));
            }
            else
            {
                Res.error = true;
                Res.errorMessage = "The matrices must be of the same size.";
            }

            return Res;
        }

        public Matrix Subtract(Matrix M)
        {
            Matrix Res = new Matrix(MatrixWidth, MatrixHeight);

            if (MatrixWidth == M.MatrixWidth && MatrixHeight == M.MatrixHeight)
            {
                for (int y = 0; y < MatrixHeight; y++)
                    for (int x = 0; x < MatrixWidth; x++)
                        Res.SetCell(x, y, Cells[x, y] - M.GetCell(x, y));
            }
            else
            {
                Res.error = true;
                Res.errorMessage = "The matrices must be of the same size.";
            }

            return Res;
        }

        public Matrix Determinant()
        {
            double lr = 0;
            double rl = 0;

            Matrix res = new Matrix(1, 1);

            if (MatrixWidth != MatrixHeight)
            {
                res.error = true;
                res.errorMessage = "The matrix must be square.";
            }
            else
            {
                // lr
                for (int x = 0; x < MatrixWidth; x++)
                {
                    for (int d = 0; d < MatrixHeight; d++)
                    {
                        lr += Cells[d, d];
                    }
                }
            }

            res.error = true;
            res.errorMessage = "Not yet implemented.";

            return res;
        }
    }
}
