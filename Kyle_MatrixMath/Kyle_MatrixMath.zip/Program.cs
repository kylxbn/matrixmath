﻿// MATRIXMATH 0.1
// Kyle Alexander Buan
// Programmed for Numerical Methods class
// November 23, 2015

using System.Collections.Generic;

namespace Kyle_MatrixMath
{
    class Program
    {
        static Dictionary<char, string> MAIN_MENU = new Dictionary<char, string>()
        {
            {'I', "Input menu" },
            {'M', "Math menu" },
            {'O', "Output menu" },
            {'T', "Transfer menu" },
            {'A', "About this program" },
            {'X', "Exit program" }
        };
        static Dictionary<char, string> INPUT_MENU = new Dictionary<char, string>()
        {
            {'Q', "Create Matrix A" },
            {'W', "Create Matrix B" },
            {'A', "Edit Matrix A"},
            {'S', "Edit Matrix B" },
            {'D', "Edit Matrix A's cell" },
            {'F', "Edit Matrix B's cell" },
            {'X', "Back to main menu" }
        };
        static Dictionary<char, string> MATH_MENU = new Dictionary<char, string>()
        {
            {'A', "C <- A + B" },
            {'S', "C <- A - B" },
            {'V', "C <- A . B" },
            {'M', "C <- A x B" },
            {'D', "C <- |A|" },
            {'X', "Back to main menu" }
        };
        static Dictionary<char, string> OUTPUT_MENU = new Dictionary<char, string>()
        {
            {'A', "Show Matrix A" },
            {'B', "Show Matrix B" },
            {'C', "Show Matrix C" },
            {'X', "Back to main menu" }
        };
        static Dictionary<char, string> TRANSFER_MENU = new Dictionary<char, string>()
        {
            {'Q', "A --> T" },
            {'W', "B --> T" },
            {'E', "C --> T" },
            {'A', "T --> A" },
            {'S', "T --> B" },
            {'D', "A <-> B" },
            {'X', "Return to main menu" }
        };
        static Dictionary<char, string> OPT_YESNO = new Dictionary<char, string>()
        {
            {'Y', "Yes" },
            {'*', "No" }
        };
        
        static SuperConsole Console = new SuperConsole();

        static Matrix MA, MB, MC, MT;

        static void Main(string[] args)
        {
            System.Console.Title = "Kyle's Matrix Math Program";

            char r;
            char r2 = 'N';

            Console.MainTitleText = "MAIN MENU";
            Console.PromptText = "PLEASE ENTER YOUR CHOICE.";
            Console.MenuOptions = MAIN_MENU;
            Console.DisplayMode = SuperConsole.DISP_MENU;
            Console.Update();

            do
            {
                Console.MainTitleText = "MAIN MENU";
                Console.PromptText = "PLEASE ENTER YOUR CHOICE.";
                Console.MenuOptions = MAIN_MENU;
                Console.DisplayMode = SuperConsole.DISP_MENU;
                r = Console.UpdateGetChar();

                switch (r)
                {
                    case 'I':
                        InputMenu();
                        break;
                    case 'M':
                        MathMenu();
                        break;
                    case 'O':
                        OutputMenu();
                        break;
                    case 'T':
                        TransferMenu();
                        break;
                    case 'A':
                        AboutMenu();
                        break;
                    case 'X':
                        Console.SetAlert("CONFIRMATION", "Do you really wish to exit\nthe program?", 1, OPT_YESNO);
                        r2 = Console.UpdateGetChar();
                        break;
                    default:
                        Console.SetAlert("ERROR", "Invalid selection", 2);
                        Console.UpdateGetChar();
                        break;
                }
            }
            while (r2 != 'Y');
        }

        static void ShowMatrix(Matrix M)
        {
            if (M == null)
            {
                Console.SetAlert("ERROR", "Matrix not yet initialized!", 2);
                Console.UpdateGetChar();
            }
            else
            {
                Console.MainTitleText = "VIEW MATRIX";
                Console.PromptText = "PRESS ANY KEY.";
                Console.DisplayMatrix = M;
                Console.DisplayMode = SuperConsole.DISP_MATRIX;
                Console.UpdateGetChar();
            }
        }

        static void InputMenu()
        {
            char r;

            int w = 0, h = 0;

            do
            {
                Console.MainTitleText = "INPUT MENU";
                Console.PromptText = "PLEASE ENTER YOUR CHOICE.";
                Console.MenuOptions = INPUT_MENU;
                Console.DisplayMode = SuperConsole.DISP_MENU;
                r = Console.UpdateGetChar();

                switch (r)
                {
                    case 'Q':
                        do
                        {
                            Console.PromptText = "PLEASE ENTER THE MATRIX COLUMN SIZE.";
                            w = Console.UpdateGetInt();
                            if (w == 0)
                            {
                                Console.SetAlert("ERROR", "Matrix columns must be at least 1.", 2);
                                Console.UpdateGetChar();
                            }
                        }
                        while (w == 0);
                        do
                        {
                            Console.PromptText = "PLEASE ENTER THE MATRIX ROW SIZE.";
                            h = Console.UpdateGetInt();
                            if (h == 0)
                            {
                                Console.SetAlert("ERROR", "Matrix rows must be at least 1.", 2);
                                Console.UpdateGetChar();
                            }
                        }
                        while (h == 0);

                        if (w == h)
                        {
                            Console.SetAlert("CREATE MATRIX A", "Do you want to make Matrix A\nan identity matrix?", 1, OPT_YESNO);
                            r = Console.UpdateGetChar();
                        }
                        if (r == 'Y' && w == h)
                            MA = new Matrix(w, h, true);
                        else
                            MA = new Matrix(w, h, false);
                        Console.SetAlert("SUCCESS", "Matrix A was successfuly created.", 0);
                        Console.UpdateGetChar();
                        break;
                    case 'W':
                        do
                        {
                            Console.PromptText = "PLEASE ENTER THE MATRIX COLUMN SIZE.";
                            w = Console.UpdateGetInt();
                            if (w == 0)
                            {
                                Console.SetAlert("ERROR", "Matrix columns must be at least 1.", 2);
                                Console.UpdateGetChar();
                            }
                        }
                        while (w == 0);
                        do
                        {
                            Console.PromptText = "PLEASE ENTER THE MATRIX ROW SIZE.";
                            h = Console.UpdateGetInt();
                            if (h == 0)
                            {
                                Console.SetAlert("ERROR", "Matrix rows must be at least 1.", 2);
                                Console.UpdateGetChar();
                            }
                        }
                        while (h == 0);

                        if (w == h)
                        {
                            Console.SetAlert("CREATE MATRIX B", "Do you want to make Matrix B\nan identity matrix?", 1, OPT_YESNO);
                            r = Console.UpdateGetChar();
                        }
                        if (r == 'Y' && w == h)
                            MB = new Matrix(w, h, true);
                        else
                            MB = new Matrix(w, h, false);
                        Console.SetAlert("SUCCESS", "Matrix B was successfuly created.", 0);
                        Console.UpdateGetChar();
                        break;
                    case 'A':
                        if (MA == null)
                        {
                            Console.SetAlert("ERROR", "Matrix A not yet initialized!", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            Console.MainTitleText = "EDIT MATRIX A";
                            Console.DisplayMatrix = MA;
                            Console.DisplayMode = SuperConsole.DISP_MATRIX;
                            for (int y = 0; y < MA.MatrixHeight; y++)
                                for (int x = 0; x < MA.MatrixWidth; x++)
                                {
                                    Console.PromptText = "ENTER VALUE FOR [" + (x+1) + ", " + (y+1) + "]";
                                    Console.MatrixColumnHighlight = x;
                                    Console.MatrixRowHighlight = y;
                                    MA.SetCell(x, y, Console.UpdateGetDouble());
                                }
                            Console.SetAlert("SUCCESS", "Matrix A successfuly edited.", 0);
                            Console.UpdateGetChar();
                            Console.MatrixRowHighlight = -1;
                            Console.MatrixColumnHighlight = -1;
                        }
                        break;
                    case 'S':
                        if (MB == null)
                        {
                            Console.SetAlert("ERROR", "Matrix B not yet initialized!", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            Console.MainTitleText = "EDIT MATRIX B";
                            Console.DisplayMatrix = MB;
                            Console.DisplayMode = SuperConsole.DISP_MATRIX;
                            for (int y = 0; y < MB.MatrixHeight; y++)
                                for (int x = 0; x < MB.MatrixWidth; x++)
                                {
                                    Console.PromptText = "ENTER VALUE FOR [" + (x+1) + ", " + (y+1) + "]";
                                    Console.MatrixColumnHighlight = x;
                                    Console.MatrixRowHighlight = y;
                                    MB.SetCell(x, y, Console.UpdateGetDouble());
                                }
                            Console.SetAlert("SUCCESS", "Matrix B successfuly edited.", 0);
                            Console.UpdateGetChar();
                            Console.MatrixRowHighlight = -1;
                            Console.MatrixColumnHighlight = -1;
                        }
                        break;
                    case 'D':
                        if (MA == null)
                        {
                            Console.SetAlert("ERROR", "Matrix A not yet initialized!", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            Console.MainTitleText = "EDIT MATRIX A CELL";
                            Console.DisplayMatrix = MA;
                            Console.DisplayMode = SuperConsole.DISP_MATRIX;
                            
                            Console.PromptText = "ENTER COLUMN TO EDIT";
                            w = Console.UpdateGetInt() - 1;
                            Console.MatrixColumnHighlight = w;
                            Console.PromptText = "ENTER ROW TO EDIT";
                            h = Console.UpdateGetInt() - 1;
                            Console.MatrixRowHighlight = h;
                            Console.PromptText = "ENTER NEW VALUE FOR [" + (w+1) + ", " + (h+1) + "]";
                            MA.SetCell(w, h, Console.UpdateGetDouble());
                                
                            Console.SetAlert("SUCCESS", "Matrix A's cell [" + (w+1) + ", " + (h+1) + "]" + "\nsuccessfuly edited.", 0);
                            Console.UpdateGetChar();
                            Console.MatrixRowHighlight = -1;
                            Console.MatrixColumnHighlight = -1;
                        }
                        break;
                    case 'F':
                        if (MB == null)
                        {
                            Console.SetAlert("ERROR", "Matrix A not yet initialized!", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            Console.MainTitleText = "EDIT MATRIX B CELL";
                            Console.DisplayMatrix = MB;
                            Console.DisplayMode = SuperConsole.DISP_MATRIX;

                            Console.PromptText = "ENTER COLUMN TO EDIT";
                            w = Console.UpdateGetInt() - 1;
                            Console.MatrixColumnHighlight = w;
                            Console.PromptText = "ENTER ROW TO EDIT";
                            h = Console.UpdateGetInt() - 1;
                            Console.MatrixRowHighlight = h;
                            Console.PromptText = "ENTER NEW VALUE FOR [" + (w + 1) + ", " + (h + 1) + "]";
                            MB.SetCell(w, h, Console.UpdateGetDouble());

                            Console.SetAlert("SUCCESS", "Matrix B's cell [" + (w + 1) + ", " + (h + 1) + "]" + "\nsuccessfuly edited.", 0);
                            Console.UpdateGetChar();
                            Console.MatrixRowHighlight = -1;
                            Console.MatrixColumnHighlight = -1;
                        }
                        break;
                    case 'X':
                        r = 'X';
                        break;
                    default:
                        Console.SetAlert("ERROR", "Invalid selection", 2);
                        Console.UpdateGetChar();
                        break;
                }
            }
            while (r != 'X');
        }

        static void MathMenu()
        {
            char r;

            do
            {
                Console.MainTitleText = "MATH MENU";
                Console.PromptText = "PLEASE ENTER YOUR CHOICE.";
                Console.MenuOptions = MATH_MENU;
                Console.DisplayMode = SuperConsole.DISP_MENU;
                r = Console.UpdateGetChar();
                
                switch (r)
                {
                    case 'A':
                        if (MA == null)
                        {
                            Console.SetAlert("ERROR", "Matrix A not yet initialized.", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            if (MB == null)
                            {
                                Console.SetAlert("ERROR", "Matrix B not yet initialized.", 2);
                                Console.UpdateGetChar();
                            }
                            else
                            {
                                MC = MA.Add(MB);

                                if (MC.error)
                                {
                                    Console.SetAlert("ERROR", MC.errorMessage, 2);
                                    Console.UpdateGetChar();
                                }
                                else
                                {
                                    Console.SetAlert("SUCCESS", "Operation successful.\nView result now?", 1, OPT_YESNO);
                                    r = Console.UpdateGetChar();
                                    if (r == 'Y')
                                        ShowMatrix(MC);
                                }
                            }
                        }
                        break;
                    case 'S':
                        if (MA == null)
                        {
                            Console.SetAlert("ERROR", "Matrix A not yet initialized.", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            if (MB == null)
                            {
                                Console.SetAlert("ERROR", "Matrix B not yet initialized.", 2);
                                Console.UpdateGetChar();
                            }
                            else
                            {
                                MC = MA.Subtract(MB);

                                if (MC.error)
                                {
                                    Console.SetAlert("ERROR", MC.errorMessage, 2);
                                    Console.UpdateGetChar();
                                }
                                else
                                {
                                    Console.SetAlert("SUCCESS", "Operation successful.\nView result now?", 1, OPT_YESNO);
                                    r = Console.UpdateGetChar();
                                    if (r == 'Y')
                                        ShowMatrix(MC);
                                }
                            }
                        }
                        break;
                }
            }
            while (r != 'X');
        }

        static void OutputMenu()
        {
            char r;

            do
            {
                Console.MainTitleText = "OUTPUT MENU";
                Console.PromptText = "PLEASE ENTER YOUR CHOICE.";
                Console.MenuOptions = OUTPUT_MENU;
                Console.DisplayMode = SuperConsole.DISP_MENU;
                r = Console.UpdateGetChar();

                switch (r)
                {
                    case 'A':
                        ShowMatrix(MA);
                        break;
                    case 'B':
                        ShowMatrix(MB);
                        break;
                    case 'C':
                        ShowMatrix(MC);
                        break;
                    case 'X':
                        r = 'X';
                        break;
                    default:
                        Console.SetAlert("ERROR", "Invalid selection", 2);
                        Console.UpdateGetChar();
                        break;
                }
            }
            while (r != 'X');
        }

        static void TransferMenu()
        {
            char r;

            do
            {
                Console.MainTitleText = "TRANSFER MENU";
                Console.PromptText = "PLEASE ENTER YOUR CHOICE.";
                Console.MenuOptions = TRANSFER_MENU;
                Console.DisplayMode = SuperConsole.DISP_MENU;
                r = Console.UpdateGetChar();

                switch (r)
                {
                    case 'Q':
                        if (MA == null)
                        {
                            Console.SetAlert("ERROR", "Matrix A not yet initialized!", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            MA.CopyTo(ref MT);
                            Console.SetAlert("SUCCESS", "Matrix A copied to Matrix T.", 0);
                            Console.UpdateGetChar();
                        }
                        break;
                    case 'W':
                        if (MB == null)
                        {
                            Console.SetAlert("ERROR", "Matrix B not yet initialized!", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            MB.CopyTo(ref MT);
                            Console.SetAlert("SUCCESS", "Matrix B copied to Matrix T.", 0);
                            Console.UpdateGetChar();
                        }
                        break;
                    case 'E':
                        if (MC == null)
                        {
                            Console.SetAlert("ERROR", "Matrix C not yet initialized!", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            MC.CopyTo(ref MT);
                            Console.SetAlert("SUCCESS", "Matrix C copied to Matrix T.", 0);
                            Console.UpdateGetChar();
                        }
                        break;
                    case 'A':
                        if (MT == null)
                        {
                            Console.SetAlert("ERROR", "Matrix T not yet initialized!", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            MT.CopyTo(ref MA);
                            Console.SetAlert("SUCCESS", "Matrix T copied to Matrix A.", 0);
                            Console.UpdateGetChar();
                        }
                        break;
                    case 'S':
                        if (MT == null)
                        {
                            Console.SetAlert("ERROR", "Matrix T not yet initialized!", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            MT.CopyTo(ref MB);
                            Console.SetAlert("SUCCESS", "Matrix T copied to Matrix B.", 0);
                            Console.UpdateGetChar();
                        }
                        break;
                    case 'D':
                        if (MA == null)
                        {
                            Console.SetAlert("ERROR", "Matrix A not yet initialized!", 2);
                            Console.UpdateGetChar();
                        }
                        else
                        {
                            if (MB == null)
                            {
                                Console.SetAlert("ERROR", "Matrix B not yet initialized!", 2);
                                Console.UpdateGetChar();
                            }
                            else
                            {
                                MA.CopyTo(ref MT);
                                MB.CopyTo(ref MA);
                                MT.CopyTo(ref MB);
                                MT = null;
                                Console.SetAlert("SUCCESS", "Matrix A and Matrix B were swapped.", 0);
                                Console.UpdateGetChar();
                            }
                        }
                        break;
                    case 'X':
                        r = 'X';
                        break;
                    default:
                        Console.SetAlert("ERROR", "Invalid selection", 2);
                        Console.UpdateGetChar();
                        break;
                }
            }
            while (r != 'X');
            MT = null;
        }

        static void AboutMenu()
        {
            string ABOUT =
                "MATRIX MATH\n" +
                "version 0.1\n\n" +

                "Programmed in C# by Kyle Alexander Buan\n" +
                "For Numerical Methods class\n\n" +

                "Submitted to Prof. Manny Bernabe\n\n" +

                "Built on November 23, 2015\n" +
                "using Microsoft Visual Studio 2015\n" +
                "for the .NET Framework 4 Client Profile\n\n" +

                "Using SuperConsole library by\n" + 
                "Kyle Alexander Buan";

            Console.SetAlert("ABOUT THIS PROGRAM", ABOUT, 1);
            Console.UpdateGetChar();
        }
    }
}
